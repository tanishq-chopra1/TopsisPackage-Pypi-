TOPSIS for MCDM (Multiple criteria decision making)
Topsis ( Technique for order for preference by similarity to Ideal solution ) in Python for UCS633 (Data Analytics & Visualization) 
complied by Tanishq Chopra, 101703579, TIET, Patiala.  